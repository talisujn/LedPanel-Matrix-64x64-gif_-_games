#ifndef SNAKEGAME_H
#define SNAKEGAME_H
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>  // Incluindo a biblioteca do display

extern MatrixPanel_I2S_DMA* dma_display;  // Declaração externa do ponteiro

struct coordenadas{
  int x = 0;
  int y = 0;
}; 

//extern coordenadas snake[100];       //vetor de struct que suporta 100 posições

void playSnake(char difficulty);
void initGame();
void sortearMaca(int n);
int collision(int c1x, int c1y, int m1[]);

#endif