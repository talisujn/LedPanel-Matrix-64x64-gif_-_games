#include "mineSweeper.h"
#include <Arduino.h> // Necessário para Serial
#include "TomThumb.h"


campo campoMinado[11][21];  // 11 linhas de 5 pixels e 21 colunas de 3 pixels      
int lin, col, quantLine = 11, quantCol = 21;
int numbomb = 0;
int alterarCor = 0;  // variavel para alternar a cor de cada casa nao aberna no jogo
bool gameOverMine = false;
int tempoInicial = 0;


void sortearBombas(int n) {  //n quantidade de bombas
    int i;
    for (i = 1; i <= n; i++) {
      lin = random(quantLine);  // o valor sera o resto do valor aleatório gerado dividido pelo tamanho da tela
      col = random(quantCol);
      if(campoMinado[lin][col].eBomba == 0) {
        campoMinado[lin][col].eBomba = 1; //adiciona bomba somente se a casa estiver sem bomba, garantindo n bombas
        numbomb ++;
      }
      else i--;

    }
}

void initGameMine(){  // percorre a matriz zerando as confugurações
  for (int lin = 0; lin < quantLine; lin++) {
      for (int col = 0; col < quantCol; col++) {
          campoMinado[lin][col].eBomba = 0;
          campoMinado[lin][col].estaAberta = 0;
          campoMinado[lin][col].vizinhos = 0;
          campoMinado[lin][col].celulaMarcada = false;
      }
  }
}


//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//contar bombas vizinhas na vizinhança de lin x col

int coordValid(int l, int c){
  if(l >= 0 && l < quantLine && c >= 0 && c < quantCol) return 1;
  else return 0;
}

int quantBombasVizinhas(int l, int c){
  int quantBomb = 0;
  if(coordValid(l-1 ,c-1) && campoMinado[l-1][c-1].eBomba) quantBomb ++; //da esquerda pra direita, de cima pra baixo
  if(coordValid(l-1, c) && campoMinado[l-1][c].eBomba) quantBomb ++;      // contanto as bombas nas 8 posicoes possiveis 
  if(coordValid(l-1, c+1) && campoMinado[l-1][c+1].eBomba) quantBomb ++;
  if(coordValid(l, c-1) && campoMinado[l][c-1].eBomba) quantBomb ++;
  if(coordValid(l, c+1) && campoMinado[l][c+1].eBomba) quantBomb ++;
  if(coordValid(l+1, c-1) && campoMinado[l+1][c-1].eBomba) quantBomb ++;
  if(coordValid(l+1, c) && campoMinado[l+1][c].eBomba) quantBomb ++;
  if(coordValid(l+1, c+1) && campoMinado[l+1][c+1].eBomba) quantBomb ++;
  return quantBomb;  
}

void bombCount(){  // percorre a matriz zerando as confugurações
  for (lin = 0; lin < quantLine; lin++) {
    for (col = 0; col < quantCol; col++) {
       campoMinado[lin][col].vizinhos = quantBombasVizinhas(lin, col);
    }
  }
} 

void imprimir(){
  
  int seguntos_total = (millis() - tempoInicial)/ 1000;
  int minutos = seguntos_total / 60;
  int segundos = seguntos_total % 60;
  
  dma_display->setFont(&TomThumb);
  dma_display->setTextSize(1);     // size 1 == 8 pixels high
  dma_display->setCursor(10, 6);
  dma_display->setTextColor(dma_display->color444(0,15,15));
  if(minutos < 10) dma_display->print("Tempo: 0" + String(minutos));
  else dma_display->print("Tempo: " + String(minutos));
  if(segundos < 10) dma_display->print(":0" + String(segundos));
  else dma_display->print(":" + String(segundos));
  

  for (int j = 0; j < quantCol; j++) {  // no painel funciona o contrario: é coluna x linha
      int linhaAlternarCor = j % 2; // Inicializa com base na paridade da linha (alternar a cada linha)
      for (int i = 0; i < quantLine; i++) {
        if(campoMinado[i][j].estaAberta == 1){ // aqui ta imprimindo as celulas abertas
          dma_display->setFont(&TomThumb);
          dma_display->setTextSize(1);  // size 1 == 8 pixels high
          dma_display->setCursor(3 * j, 5 * i + 9 + 5);
          if (campoMinado[i][j].vizinhos == 1) dma_display->setTextColor(dma_display->color444(0,100,100));
          else if (campoMinado[i][j].vizinhos == 2) dma_display->setTextColor(dma_display->color444(0,255,0));
          else if (campoMinado[i][j].vizinhos == 3) dma_display->setTextColor(dma_display->color444(200,20,20));
          if (campoMinado[i][j].vizinhos != 0) dma_display->print(campoMinado[i][j].vizinhos); // esssa funcao usa o padrao linha coluna
        }
        else{
          if(campoMinado[i][j].celulaMarcada == true) // campo marcado como uma bomba
            dma_display->fillRect(3 * j, 9 + 5 * i, 3, 5, dma_display->color444(255, 255, 0)); //amarelo bomba marcada
          else{
            // Alterna cores com base em (linha + coluna) % 2
            if((i + j) % 2 == 0)
              dma_display->fillRect(3 * j, 9 + 5 * i, 3, 5, dma_display->color444(128, 0, 128));  //marrom - esses dois ifs irao alternar as cores dos quadrados             
            else// primeiro faz a matriz de cores alternadas
              dma_display->fillRect(3 * j, 9 + 5 * i, 3, 5, dma_display->color444(255, 0, 255)); //verde -  o 
            linhaAlternarCor = !linhaAlternarCor; // Alterna para a próxima célula          
          }          
        }       
      }          
     }
}

//abre a coordenada atual na matriz caso selecionada  (função recursiva)
void abrirCelula(int l, int c){
  ///Serial.println("abrindo celula");
  if(coordValid(l, c) == 1 && campoMinado[l][c].estaAberta == 0){
    campoMinado[l][c].estaAberta = 1; // abre a posição
    if(campoMinado[l][c].vizinhos == 0){ // se a posicao aberta tem 0 vizinhos chama a funçao novamente para verificar para essa posição(função recursiva)
      abrirCelula(l-1 ,c-1);  //da esquerda pra direita, de cima pra baixo
      abrirCelula(l-1, c);    // verifica para cada vizinho se tem 0 vizinhos
      abrirCelula(l-1, c+1); // aqui todas as casas com 0 vizinhos sao abertas 
      abrirCelula(l, c-1); 
      abrirCelula(l, c+1);
      abrirCelula(l+1, c-1);
      abrirCelula(l+1, c);
      abrirCelula(l+1, c+1);
    }
  }

}
// função verificar vitória
int ganhou(){ // se tiver celulas fehcadas que nao sao bomba usuário ainda não ganhou 
  int quantidade = 0; // quantidades de celulas nao bomba fechadas 
  for (int j = 0; j < quantCol; j++) {  // no painel funciona o contrario: é coluna x linha
    for (int i = 0; i < quantLine; i++) {
      if(campoMinado[i][j].estaAberta == 0 && campoMinado[i][j].eBomba == 0)
        quantidade ++;
    }
  }
  return quantidade; // quando quantidade == 0 usuário ganhou
}

// procedimento atualiza a coordenadas atual na matriz
void jogar(){
  int linhaAtual = 0, colunaAtual = 0;
  bool celula = false , marcarBomba = false;
  do{
    do{
      delay(50);
      dma_display->clearScreen();
      imprimir();
      char tecla = 0;
      if (Serial.available() > 0) { // Garante que há algo para ler
        tecla = Serial.read();
      }
      celula = false;
      marcarBomba = false;
      dma_display->fillRect(3 * colunaAtual, 9 + 5 * linhaAtual, 3, 5,
                           (campoMinado[linhaAtual][colunaAtual].celulaMarcada && (millis() / 500) % 2 == 0) 
                           ? dma_display->color444(255, 255, 0) // Amarelo para bomba marcada
                           : dma_display->color444(255, 255, 255)); // Branco para posição do jogador 
      if (tecla == 'w' && linhaAtual > 0) linhaAtual --;     
      if (tecla == 's' && linhaAtual < 10) linhaAtual ++;
      if (tecla == 'a' && colunaAtual > 0) colunaAtual --;
      if (tecla == 'd' && colunaAtual < 20) colunaAtual ++;
      if (tecla == 'm') celula = true;
      if (tecla == 'b') campoMinado[linhaAtual][colunaAtual].celulaMarcada = true; // opção marcar bombas 
      if (tecla == 'v') campoMinado[linhaAtual][colunaAtual].celulaMarcada = false; // opção desmarcar bombas 
      if (tecla == 'q' ) return;
      //delay(32); // na teoria pra obter 30 fps(1000/30)
    }while(campoMinado[linhaAtual][colunaAtual].estaAberta == 1 || celula == false);
    abrirCelula(linhaAtual, colunaAtual);
    if (gameOverMine) break;
  }while(ganhou() != 0 && campoMinado[linhaAtual][colunaAtual].eBomba == 0); // se igual 0 usuário ganhou e parar de abrir célula

  if(campoMinado[linhaAtual][colunaAtual].eBomba == 1 ) {
    gameOverMine = true; //jogador perdeu
    //Serial.println("é bomba");
    dma_display->fillRect(3 * colunaAtual, 9 + 5 * linhaAtual, 3, 5, dma_display->color444(255, 0, 0)); // imprime a bomba atual
    for (int j = 0; j < quantCol; j++) {  // no painel funciona o contrario: é coluna x linha
    for (int i = 0; i < quantLine; i++) {
      if(campoMinado[i][j].eBomba == 1 ){
        dma_display->fillRect(3 * j, 9 + 5 * i, 3, 5, dma_display->color444(255, 0, 0)); // imprime todas as outras bombas
        delay(500);
      }
    }
  }

  }
  else {
    dma_display->setTextSize(2);     // imprime na tela que ganhou o jogo
    dma_display->setCursor(10, 30);
    dma_display->setTextColor(dma_display->color444(255,0,0));
    dma_display->print("Boa bb");
    //Serial.println("Vitória!!!!!!!!");
    delay(5000);
  }
    delay(1000);
}





//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> loop mine sweeper
void playMineSweeper(char difficulty){
  if (difficulty == 'e') numbomb = 10;
  else if (difficulty == 'm') numbomb = 18;
  else if (difficulty == 'h') numbomb = 24;
  initGameMine();
  sortearBombas(numbomb);
  bombCount();

  tempoInicial = millis();
  while (!gameOverMine ){
    jogar();
  }
  char tecla = '\0';
  while (gameOverMine && tecla != 'q') {
    dma_display->clearScreen();
    dma_display->setFont(NULL); // voltar a fonte padrão
    dma_display->setTextSize(1);     // size 1 == 8 pixels high
    dma_display->setCursor(4, 25);
    dma_display->setTextColor(dma_display->color444(0,15,15));
    dma_display->print("Game Over!");
    dma_display->setCursor(4, 50); // coluna linha
    dma_display->print("Q to quit");
    tecla = Serial.read();
    delay(1000);
  }
  gameOverMine = false;
  return;
}