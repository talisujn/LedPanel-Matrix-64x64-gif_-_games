#include "snakeGame.h"
#include <Arduino.h> // Necessário para Serial
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>  // Incluindo a biblioteca do display

extern MatrixPanel_I2S_DMA* dma_display;  // Ponteiro externo, declarado como global no setup.

int snakeLenght = 0;    //Tamanho inicial da cobra
char direcao = 'd';
int pixels_corpo = 0;
int quant_maca = 0;
int telaGameX = 60;
int telaGameY = 52; // area util para x e y em quant de colunas e linhas
int score = 0;
bool gameOver = false;
coordenadas applePos[10];
// definindo valores pra representa as direções da cobra

coordenadas snake[100];

void initGame(){
  snake[0].x = 6;  //
  snake[0].y = 26;
}
   
void sortearMaca(int numero) {
  bool validPosition;
  do {
    validPosition = true;
    // Gera posição aleatória
    applePos[numero].x = 2 + (random(telaGameX / pixels_corpo) * pixels_corpo);
    applePos[numero].y = 10 + (random(telaGameY / pixels_corpo) * pixels_corpo);
    //applePos[numero].x = 2 + random(telaGameX) * numero;
    //applePos[numero].y = 10 + random(telaGameY) * numero;

    // Verifica se a posição colide com a cobra
    for (int j = 0; j <= snakeLenght; j++) {
      if (snake[j].x == applePos[numero].x && snake[j].y == applePos[numero].y) {
        validPosition = false;
        break;
      }
    }

    // Verifica colisão com outras maçãs
    for (int j = 0; j < quant_maca; j++) {
      if (j != numero && applePos[j].x == applePos[numero].x && applePos[j].y == applePos[numero].y) {
        validPosition = false;
        break;
      }
    }
  } while (!validPosition);
}

int collision(int c1x, int c1y, coordenadas applePos){  // recebe como parametros os vetores de posicao da cabeça e da maça
  return (c1x == applePos.x && c1y == applePos.y); // colidindo cabeça e maça, c1 e c2 
}
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> snake game loop


void playSnake(char difficulty){
  if (difficulty == 'e') { quant_maca = 1; pixels_corpo = 4;}
  else if (difficulty == 'm') { quant_maca = 2; pixels_corpo = 2;}
  else if (difficulty == 'h') { quant_maca = 4; pixels_corpo = 1;}
  
  initGame();
  for (int i = 0; i < quant_maca; i++) {
    sortearMaca(i); // Gera as posições iniciais para todas as maçãs
  }
  char tecla = '\0';

  while(!gameOver){
    //dma_display->drawRect(0, 9, dma_display->width(), dma_display->height()- 9, dma_display->color444(100, 100, 200));
    dma_display->drawRect(0, 8, dma_display->width(), dma_display->height()- 8, dma_display->color444(100, 100, 200));
    dma_display->drawRect(1, 9, dma_display->width()- 2, dma_display->height()- 10, dma_display->color444(100, 100, 200));

    tecla = Serial.read();
    if (tecla == 'w' & direcao != 's')  direcao = 'w';
    if (tecla == 's' & direcao != 'w')  direcao = 's';
    if (tecla == 'a' & direcao != 'd')  direcao = 'a';
    if (tecla == 'd' & direcao != 'a')  direcao = 'd';// ate aqui é pra movimentar a cabeça para as direcoes
    if (tecla == 'q' ) { gameOver = false; snakeLenght = 0; score = 0; return;}
    // se pegar a maça sortear outra e aumentar o tamanho
    for (int i = 0; i < quant_maca; i++) {
      if(collision(snake[0].x, snake[0].y, applePos[i])){      
        sortearMaca(i); //nova posição para a maça     
        snakeLenght++;  // adiciona um pedaço no rabo da cobra
        score++; 
      }
    }

    // moviment snake
    for (int i = snakeLenght; i > 0; i--) {
      snake[i] = snake[(i - 1)];  // cada pedaço assume a posição anterior comecando do rabo
    }

    if (direcao == 'w') snake[0].y = snake[0].y - pixels_corpo;   
    if (direcao == 's') snake[0].y =  snake[0].y + pixels_corpo;
    if (direcao == 'a') snake[0].x = snake[0].x - pixels_corpo;
    if (direcao == 'd') snake[0].x = snake[0].x + pixels_corpo;

    // snake teleport function
    if (snake[0].x >= 62) snake[0].x = 2; // x coluna
    if (snake[0].x <= 1) snake[0].x = 63 - 1 - pixels_corpo; //y linha
    if (snake[0].y >= 62) snake[0].y = 10; 
    if (snake[0].y <= 9) snake[0].y = 63 - 1 - pixels_corpo;  // usa o tamanho do corpo para saber para onde teleportar

    // Check if the snake has hit itself
    for (int i = 1; i <= snakeLenght; i++){
        if (snake[0].x == snake[i].x && snake[0].y == snake[i].y){
          gameOver = true;
          break;
        }   
    }
    for (int j = 0; j <= snakeLenght; j++) { // desenha os quadrados da cobra
      dma_display->fillRect(snake[j].x, snake[j].y, pixels_corpo, pixels_corpo, dma_display->color444(100, 100, 100));
    }

    // imprime a maca na tela
    for (int i = 0; i < quant_maca; i++) {
      dma_display->fillRect(applePos[i].x, applePos[i].y, pixels_corpo, pixels_corpo, dma_display->color444(255, 0, 0));
    }

    dma_display->setTextSize(1);     // size 1 == 8 pixels high
    dma_display->setCursor(5, 0);
    dma_display->setTextColor(dma_display->color444(0,15,15));
    dma_display->print("Score: ");
    dma_display->print(score);
    delay(250/quant_maca);
    dma_display->clearScreen();
  }

  while (gameOver && tecla != 'q') {
    dma_display->clearScreen();
    dma_display->setTextSize(1);     // size 1 == 8 pixels high
    dma_display->setCursor(4, 25);
    dma_display->setTextColor(dma_display->color444(0,15,15));
    dma_display->print("Game Over!");
    dma_display->setCursor(4, 50); // coluna linha
    dma_display->print("Q to quit");
    tecla = Serial.read();
    delay(1000);
  }
  gameOver = false;
  snakeLenght = 0;
  score = 0;
  return;
}