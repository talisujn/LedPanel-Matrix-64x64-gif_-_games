#include "menu.h"
#include <Arduino.h> // Necessário para Serial
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>  // Incluindo a biblioteca do display

extern MatrixPanel_I2S_DMA* dma_display;  // Ponteiro externo, declarado como global no setup.

MenuSelection menu(){
  MenuSelection selection = {0, '\0'};

  dma_display->clearScreen();
  dma_display->setTextSize(1);     // size 1 == 8 pixels high
  dma_display->setTextColor(dma_display->color444(60,30,200));
  dma_display->setCursor(10, 5);
  dma_display->print("Select:");
  dma_display->setCursor(0, 20);
  dma_display->print("Brigthness(1-255)");
  int brightness = 0;
  do{
    brightness = Serial.parseInt();
  }while(brightness <= 0 || brightness > 255);
  dma_display->setBrightness8(brightness);
  dma_display->clearScreen();

  char option = '\0';
  while(true){
    dma_display->setTextSize(1);     // size 1 == 8 pixels high
    dma_display->setTextColor(dma_display->color444(60,30,200));
    dma_display->setCursor(15, 0);
    dma_display->print("Menu:");
    dma_display->setCursor(0, 15);
    dma_display->print("1.Snake");
    dma_display->setCursor(0, 25);
    dma_display->print("2.Mine");
    dma_display->setCursor(12, 35);
    dma_display->print("Sweeper");
    dma_display->setCursor(0, 45);
    dma_display->print("3.Gifs");
    //dma_display->setCursor(5, 40);
    //dma_display->print("Dificil:3");
    option = Serial.read();

    if (option == '1' || option =='2') {
      dma_display->clearScreen();
      while (true) {
        dma_display->setCursor(17, 5);
        if(option == '1') dma_display->print( "Snake");
        else{
          dma_display->setCursor(19, 1); 
          dma_display->print("Mine");
          dma_display->setCursor(11, 10);
          dma_display->print("Sweeper");
        }
        dma_display->setCursor(0, 20);
        dma_display->print("E Easy");
        dma_display->setCursor(0, 30);
        dma_display->print("M Medium");
        dma_display->setCursor(0, 40);
        dma_display->print("H Hard");
        char dif = Serial.read();
        if (dif == 'e' || dif == 'm' || dif == 'h') {
          selection.game = (option == '1') ? 1 : 2;
          selection.difficulty = dif;
          return selection; // Retorna a seleção
        }
      }
    }
    else if (option == '3') {
      selection.game = 3;
      selection.difficulty = 'g'; // 'g' para indicar GIFs
      return selection; // Retorna a seleção
    }
  }
}
