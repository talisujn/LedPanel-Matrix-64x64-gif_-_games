#ifndef MENU_H
#define MENU_H
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>  // Incluindo a biblioteca do display

extern MatrixPanel_I2S_DMA* dma_display;  // Declaração externa do ponteiro

struct MenuSelection {
  int game;        // 1: Snake, 2: Mine Sweeper, 3: GIFs
  char difficulty; // 'f', 'm', 'd' ou 'g' para GIFs
};
MenuSelection menu();

#endif
