#ifndef MINESWEEPER_H
#define MINESWEEPER_H
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>  // Incluindo a biblioteca do display

extern MatrixPanel_I2S_DMA* dma_display;  // Declaração externa do ponteiro

struct campo{
  int eBomba;
  int estaAberta;
  int vizinhos;
  bool celulaMarcada;
};

void playMineSweeper(char difficulty);

#endif